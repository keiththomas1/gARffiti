'use strict';
let mongoose = require('mongoose');
let Schema = mongoose.Schema;

let LocationSchema = new Schema({
	latitude: String,
	longitude: String,
	photo: Buffer,
	worldMap: Buffer,
	contributors: {
		type: String,
		default: "1"
	},
	createdDate: {
		type: Date,
		default: Date.now
	},
});

module.exports = mongoose.model('Locations', LocationSchema);
